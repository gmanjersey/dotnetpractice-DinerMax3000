﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DinerMax3000Console
{
    public class FoodMenu:Menu
    {
        public string HospitalDirections;

    }
}
